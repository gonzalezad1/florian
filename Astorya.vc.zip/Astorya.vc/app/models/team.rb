class Team < ApplicationRecord
end
